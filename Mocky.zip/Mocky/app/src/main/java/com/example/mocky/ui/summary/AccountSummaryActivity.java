package com.example.mocky;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.mocky.adapters.SummaryList;
import com.example.mocky.ui.transactions.TransactionHistoryActivity;
import com.example.mocky.utils.CommonUtils;
import com.example.mocky.utils.HttpUtils;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

import static com.example.mocky.utils.AppConstants.END_POINT_SUMMARY;

public class AccountSummaryActivity extends Activity {

    ListView listView = null;
    private Dialog mLoaderDialog = null;

    // Show Toast messages
    void showToast(CharSequence msg, int success) {
        LayoutInflater inflater = getLayoutInflater();
        View toastLayout = inflater.inflate(R.layout.custom_toast, (ViewGroup) findViewById(R.id.custom_toast_layout));
        CommonUtils sharedData = (CommonUtils) getApplicationContext();
        sharedData.showToastWithText(msg, success, toastLayout);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_summary);

        // Components reference
        listView = findViewById(R.id.listView);

        // Loader
        View view = getLayoutInflater().inflate(R.layout.custom_loader, null);
        mLoaderDialog = new Dialog(this, R.style.TransparentTheme);
        mLoaderDialog.setContentView(view);
        mLoaderDialog.setCancelable(true);
        mLoaderDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        // account summary service call
        showAllAccountSummaryLists();
    }

    // Account summary service method
    public void showAllAccountSummaryLists() {

        if (com.example.mocky.Connectivity.isConnected(this)) {

            RequestParams reqParam = new RequestParams();

            HttpUtils.post(this, END_POINT_SUMMARY, reqParam, new JsonHttpResponseHandler() {

                // Start Progress
                public void onStart() {
                    super.onStart();
                    mLoaderDialog.show();
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    // If the response is JSONObject instead of expected JSONArray
                    try {
                        JSONObject successResJson = new JSONObject(response.toString());
                        JSONArray successResArr = successResJson.getJSONArray("accounts");
                        int length = successResArr.length();

                        // Check the length of data's
                        if (length > 0) {
                            String[] accDetails = new String[successResArr.length()];
                            SummaryList accList = new SummaryList(AccountSummaryActivity.this, accDetails, successResArr);

                            // setting adapter to List
                            listView.setAdapter(accList);

                            // Button actions (Listener)
                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    // getting value from adapter
                                    String accountLabel = (String) ((TextView) view.findViewById(R.id.accountLabel)).getText();
                                    String accountNumber = (String) ((TextView) view.findViewById(R.id.accountNumber)).getText();
                                    String availableBalance = (String) ((TextView) view.findViewById(R.id.availableBalance)).getText();
                                    String transactions = (String) ((TextView) view.findViewById(R.id.transactions)).getText();

                                    // Move to Transaction list
                                    Intent i = new Intent(AccountSummaryActivity.this, TransactionHistoryActivity.class);
                                    i.putExtra("accountLabel", accountLabel);
                                    i.putExtra("accountNumber", accountNumber);
                                    i.putExtra("availableBalance", availableBalance);
                                    i.putExtra("transactions", transactions);
                                    startActivity(i);
                                }
                            });
                        } else {
                            // Error toast message
                            showToast("Empty data", 0);
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                    super.onFailure(statusCode, headers, throwable, errorResponse);
                    showToast(getString(R.string.server_msg), 0);
                }

                // Stop Progress
                public void onFinish() {
                    super.onFinish();
                    if (mLoaderDialog != null) {
                        mLoaderDialog.dismiss();
                    }
                }

            });
        } else {
            showToast(getResources().getString(R.string.no_internet), 0);
        }
    }

    // Menu action
    public void menuAction(View view) {
        showToast("Menu action!!!", 1);
    }

    // logout action
    public void logoutAction(View view) {
        showToast("Logout action!!!", 1);
    }

}

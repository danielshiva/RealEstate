package com.example.mocky.utils;

import android.app.Application;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mocky.R;

public class CommonUtils extends Application {

    // Custom Toast
    public void showToastWithText(CharSequence text, int status, View toastLayout) {
        // Assign colors
        if (status == 0)        // Failure
            toastLayout.setBackgroundColor(Color.parseColor("#e94f1d"));
        else if (status == 1)    // Success
            toastLayout.setBackgroundColor(Color.parseColor("#3a9a69"));
        else                    // Message
            toastLayout.setBackgroundColor(Color.parseColor("#3a9a69"));

        TextView showText = toastLayout.findViewById(R.id.custom_toast_message);
        showText.setTextColor(Color.parseColor("#ffffff"));
        showText.setText(text);

        Toast toast = new Toast(getApplicationContext());
        toast.setGravity(Gravity.BOTTOM | Gravity.FILL_HORIZONTAL, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(toastLayout);
        toast.show();
    }
}

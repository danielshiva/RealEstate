package com.example.mocky.utils;

public final class AppConstants {

    public static final int CONNECTION_TIMEOUT = 60000;

    public static final String ACCOUNT_SUMMARY_URL = "http://www.mocky.io/v2/";
    public static final String END_POINT_SUMMARY = "5abb1042350000580073a7ea";

    public static final String AVAILABLE_BALANCE = "Available  $";
    public static final String CURRENT_BALANCE = "Current $";

    public static final String AMOUNT = "$";

    private AppConstants() {
        // This utility class is not publicly instantiable
    }

}

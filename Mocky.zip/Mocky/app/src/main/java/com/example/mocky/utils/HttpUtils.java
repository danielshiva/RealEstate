package com.example.mocky.utils;

import android.content.Context;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import static com.example.mocky.utils.AppConstants.ACCOUNT_SUMMARY_URL;
import static com.example.mocky.utils.AppConstants.CONNECTION_TIMEOUT;

public class HttpUtils {

    private static AsyncHttpClient client = new AsyncHttpClient(true, 80, 443);

    public static void get(Context context, String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.get(getAbsoluteUrl(url), params, responseHandler);
    }

    public static void post(Context context, String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.setTimeout(CONNECTION_TIMEOUT);
        client.post(getAbsoluteUrl(url), params, responseHandler);
    }

    public static void addHeaders(String header, String value) {
        client.addHeader(header, value);
    }

    public static void getByUrl(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.get(url, params, responseHandler);
    }

    public static void postByUrl(String url, RequestParams params, AsyncHttpResponseHandler responseHandler) {
        client.post(url, params, responseHandler);
    }

    private static String getAbsoluteUrl(String relativeUrl) {
        return ACCOUNT_SUMMARY_URL + relativeUrl;
    }
}

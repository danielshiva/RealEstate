package com.example.mocky.ui.transactions;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.mocky.R;
import com.example.mocky.adapters.TransactionList;
import com.example.mocky.utils.CommonUtils;
import com.example.mocky.utils.HttpUtils;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class TransactionHistoryActivity extends Activity {

    ListView listView = null;
    private Dialog mLoaderDialog = null;
    private String accountLabel;
    private String accountNumber;
    private String availableBalance;
    private String transactions;

    // Show Toast messages
    void showToast(CharSequence msg, int success) {
        LayoutInflater inflater = getLayoutInflater();
        View toastLayout = inflater.inflate(R.layout.custom_toast, (ViewGroup) findViewById(R.id.custom_toast_layout));
        CommonUtils sharedData = (CommonUtils) getApplicationContext();
        sharedData.showToastWithText(msg, success, toastLayout);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_list);

        //Get values from Previous screen
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            accountLabel = extras.getString("accountLabel");
            accountNumber = extras.getString("accountNumber");
            availableBalance = extras.getString("availableBalance");
            transactions = extras.getString("transactions");
        }

        // Components reference
        listView = findViewById(R.id.listView);
        TextView accountLabelText = findViewById(R.id.accountLabel);
        TextView accountNumberText = findViewById(R.id.accountNumber);
        TextView availableBalanceText = findViewById(R.id.availableBalance);

        // Loader
        View view = getLayoutInflater().inflate(R.layout.custom_loader, null);
        mLoaderDialog = new Dialog(this, R.style.TransparentTheme);
        mLoaderDialog.setContentView(view);
        mLoaderDialog.setCancelable(true);
        mLoaderDialog.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        // setting values to textView's
        accountLabelText.setText(accountLabel);
        accountNumberText.setText(accountNumber);
        availableBalanceText.setText(availableBalance);

        // transactions history service call
        showAllTransactionLists();

    }

    // transactions history service method
    public void showAllTransactionLists() {

        if (com.example.mocky.Connectivity.isConnected(this)) {

            // SubString the static text's from URL
            String END_POINT_SUMMARY = transactions.substring(23);

            RequestParams reqParam = new RequestParams();

            HttpUtils.post(this, END_POINT_SUMMARY, reqParam, new JsonHttpResponseHandler() {

                // Start Progress
                public void onStart() {
                    super.onStart();
                    mLoaderDialog.show();
                }

                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    // If the response is JSONObject instead of expected JSONArray
                    try {
                        JSONObject successResJson = new JSONObject(response.toString());
                        JSONArray successResArr = successResJson.getJSONArray("transactions");
                        int length = successResArr.length();

                        // Check the length of data's
                        if (length > 0) {
                            String[] accDetails = new String[successResArr.length()];
                            TransactionList accList = new TransactionList(TransactionHistoryActivity.this, accDetails, successResArr);

                            // setting adapter to List
                            listView.setAdapter(accList);

                        } else {
                            // Error toast message
                            showToast("Empty data", 0);
                        }
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                    super.onFailure(statusCode, headers, throwable, errorResponse);
                    showToast(getString(R.string.server_msg), 0);
                }

                // Stop Progress
                public void onFinish() {
                    super.onFinish();
                    if (mLoaderDialog != null) {
                        mLoaderDialog.dismiss();
                    }
                }

            });
        } else {
            showToast(getResources().getString(R.string.no_internet), 0);
        }
    }

    // logout action
    public void filterAction(View view) {
        showToast("Filter action!!!", 1);
    }

    // back action
    public void actionBack(View view) {
        finish();
    }

    // hardware back button action
    @Override
    public void onBackPressed() {
        finish();
    }
}

package com.example.mocky.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.mocky.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.example.mocky.utils.AppConstants.AMOUNT;

public class TransactionList extends ArrayAdapter<String> {

    Context context;
    private String[] accList;
    private JSONArray accDetails;

    public TransactionList(Context context, String[] accList, JSONArray accDetails) {
        super(context, R.layout.layout_transaction_history, accList);
        this.context = context;
        this.accList = accList;
        this.accDetails = accDetails;
    }

    public class Holder {
        TextView date;
        TextView description;
        TextView amount;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        TransactionList.Holder viewHolder; // view lookup cache stored in tag

        if (convertView == null) {

            viewHolder = new TransactionList.Holder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.layout_transaction_history, parent, false);

            // Component reference
            viewHolder.date = convertView.findViewById(R.id.date);
            viewHolder.description = convertView.findViewById(R.id.description);
            viewHolder.amount = convertView.findViewById(R.id.amount);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (TransactionList.Holder) convertView.getTag();
        }

        // Assigning values to labels
        JSONObject dataArrayJSONResp = null;
        try {
            dataArrayJSONResp = this.accDetails.getJSONObject(position);
            viewHolder.date.setText(getFormatedDate(dataArrayJSONResp.getString("date")));
            viewHolder.description.setText(dataArrayJSONResp.getString("description"));
            viewHolder.amount.setText(AMOUNT + dataArrayJSONResp.getString("amount"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Return the completed view to render on screen
        return convertView;
    }

    // convert date format
    public String getFormatedDate(String dateString) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = format.parse(dateString);
            System.out.println(date);
            String datetime = format.format(date);
            return datetime;
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "";
        }
    }
}

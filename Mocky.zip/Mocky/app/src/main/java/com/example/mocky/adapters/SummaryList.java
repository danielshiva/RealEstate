package com.example.mocky.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.mocky.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.example.mocky.utils.AppConstants.AVAILABLE_BALANCE;
import static com.example.mocky.utils.AppConstants.CURRENT_BALANCE;


public class SummaryList extends ArrayAdapter<String> {

    Context context;
    private String[] accList;
    private JSONArray accDetails;

    public SummaryList(Context context, String[] accList, JSONArray accDetails) {
        super(context, R.layout.layout_summary, accList);
        this.context = context;
        this.accList = accList;
        this.accDetails = accDetails;
    }

    public class Holder {
        TextView accountLabel;
        TextView accountNumber;
        TextView availableBalance;
        TextView currentBalance;
        TextView transactions;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Holder viewHolder; // view lookup cache stored in tag

        if (convertView == null) {

            viewHolder = new Holder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.layout_summary, parent, false);

            // Component reference
            viewHolder.accountLabel = convertView.findViewById(R.id.accountLabel);
            viewHolder.accountNumber = convertView.findViewById(R.id.accountNumber);
            viewHolder.availableBalance = convertView.findViewById(R.id.availableBalance);
            viewHolder.currentBalance = convertView.findViewById(R.id.currentBalance);
            viewHolder.transactions = convertView.findViewById(R.id.transactions);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (Holder) convertView.getTag();
        }

        // Assigning values to labels
        JSONObject dataArrayJSONResp = null;
        try {
            dataArrayJSONResp = this.accDetails.getJSONObject(position);
            viewHolder.accountLabel.setText(dataArrayJSONResp.getString("accountLabel"));
            viewHolder.accountNumber.setText(dataArrayJSONResp.getString("accountNumber"));
            viewHolder.availableBalance.setText(AVAILABLE_BALANCE + dataArrayJSONResp.getString("availableBalance"));
            viewHolder.currentBalance.setText(CURRENT_BALANCE + dataArrayJSONResp.getString("currentBalance"));
            viewHolder.transactions.setText(dataArrayJSONResp.getString("transactions"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        // Return the completed view to render on screen
        return convertView;
    }

}
